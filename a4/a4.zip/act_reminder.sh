myweekly act.txt

day =  date "+%A"

if [day = Monday]; then
echo "$(sed -n '1,1p' myweekly_act.txt)" | mailx -s "Reminder: Tasks for today" pr338@cornell.edu
fi

if [day = Tuesday]; then
echo "$(sed -n '2,2p' myweekly_act.txt)" | mailx -s "Reminder: Tasks for today" pr338@cornell.edu
fi

if [day = Wednesday]; then
echo "$(sed -n '3,3p' myweekly_act.txt)" | mailx -s "Reminder: Tasks for today" pr338@cornell.edu
fi

if [day = Thursday]; then
echo "$(sed -n '4,4p' myweekly_act.txt)" | mailx -s "Reminder: Tasks for today" pr338@cornell.edu
fi

if [day = Friday]; then
echo "$(sed -n '5,5p' myweekly_act.txt)" | mailx -s "Reminder: Tasks for today" pr338@cornell.edu
fi


